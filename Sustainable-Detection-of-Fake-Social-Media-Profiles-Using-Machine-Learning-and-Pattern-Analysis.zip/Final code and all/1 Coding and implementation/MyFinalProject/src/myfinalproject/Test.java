/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package myfinalproject;
import java.sql.*;
/**
 *
 * @author vibha
 */
public class Test{
  public static void main(String[] args) throws Exception {
  String driver = "com.mysql.jdbc.Driver";
  String url = "jdbc:mysql://localhost:3306/";
  String username = "root";
  String password = "root";
  String dbName= "any";
  Class.forName(driver);
  Connection conn = DriverManager.getConnection(
  url+dbName,
  username,
  password);
  System.out.println("Connected");
  Statement st = conn.createStatement();
  ResultSet rs = st.executeQuery("SELECT * FROM webpages");
  ResultSetMetaData rsmd = rs.getMetaData();
  int NumOfCol = rsmd.getColumnCount();
  for(int i=1;i<=NumOfCol;i++)
  {
  System.out.println("Name of ["+i+"] Column data type is ="
   +rsmd.getColumnTypeName(i));
  }
  st.close();
  conn.close();
  } 
}
