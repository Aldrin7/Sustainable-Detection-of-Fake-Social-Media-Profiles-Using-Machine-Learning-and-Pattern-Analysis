/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package myfinalproject;

/**
 *
 * @author vibha
 */
public class MyDataSet {
    

public String age;
public String sex;
public String occupation;
public String familyhistroy;
public String smoking;
public String alchohal;
public String tobacco;
public String weight;
public String cholestrol;
public String HBP;
public String LBP;
public String Diabetes;
public String Stress;
public String target;






public MyDataSet()
{
   
    this.age="";
    this.sex="";
    this.occupation="";
    this.familyhistroy="";
    this.Diabetes="";
    this.HBP="";
    this.LBP="";
    this.cholestrol="";
    this.target="";
    this.tobacco="";
    this.Stress="";
    this.smoking="";
    this.weight="";
    this.alchohal="";
}
        
}
