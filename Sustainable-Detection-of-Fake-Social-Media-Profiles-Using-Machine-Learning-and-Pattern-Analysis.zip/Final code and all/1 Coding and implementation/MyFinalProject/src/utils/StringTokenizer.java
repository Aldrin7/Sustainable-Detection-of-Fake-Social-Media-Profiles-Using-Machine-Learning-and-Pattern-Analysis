/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils;

import com.sun.xml.internal.bind.Util;
import com.sun.xml.internal.bind.Util;
import java.sql.Ref;
import java.util.ArrayList;

/**
 *
 * @author vibha
 */
public class StringTokenizer {
protected int m_CurrIndex;
		protected int m_NumTokens;
		protected ArrayList m_Tokens;
	        public  String m_StrSource;

		public  String m_StrDelimiter;
		public StringTokenizer(String source, String delimiter)
		{
			this.m_Tokens = new ArrayList(10);
			this.m_StrSource = source;
			this.m_StrDelimiter = delimiter;
			if (delimiter.length() == 0) {
				this.m_StrDelimiter = " ";
			}
			this.Tokenize();
		}

		public StringTokenizer(String source, char[] delimiter) 
		{
                     this(source, new String(delimiter));
		}

		public StringTokenizer(String source) 
		{
                     this(source, "");
		}

		public StringTokenizer() 
		{
                     this("", "");
		}

		private void Tokenize()
		{
			String TempSource = this.m_StrSource;
			String Tok = "";
			this.m_NumTokens = 0;
			this.m_Tokens.clear();
			this.m_CurrIndex = 0;
			if (TempSource.indexOf(this.m_StrDelimiter) < 0 && TempSource.length() > 0) {
				this.m_NumTokens = 1;
				this.m_CurrIndex = 0;
				this.m_Tokens.add(TempSource);
				this.m_Tokens.trimToSize();
				TempSource = "";
			} else {
				if (TempSource.indexOf(this.m_StrDelimiter) < 0 && TempSource.length() <= 0) {
					this.m_NumTokens = 0;
					this.m_CurrIndex = 0;
					this.m_Tokens.trimToSize();
				}
			}
			while (TempSource.indexOf(this.m_StrDelimiter) >= 0) {
				if (TempSource.indexOf(this.m_StrDelimiter) == 0) {
					if (TempSource.length() > this.m_StrDelimiter.length()) {
						TempSource = TempSource.substring(this.m_StrDelimiter.length());
					} else {
						TempSource = "";
					}
				} else {
					Tok = TempSource.substring(0, TempSource.indexOf(this.m_StrDelimiter));
                                        //System.out.println( TempSource.indexOf(this.m_StrDelimiter));
					this.m_Tokens.add(Tok);
					if (TempSource.length() > (this.m_StrDelimiter.length() + Tok.length())) {
						TempSource = TempSource.substring(this.m_StrDelimiter.length() + Tok.length());
					} else {
						TempSource = "";
					}
				}
			}
			if (TempSource.length() > 0) {
				this.m_Tokens.add(TempSource);
			}
			this.m_Tokens.trimToSize();
			this.m_NumTokens = this.m_Tokens.size();
		}

		public void NewSource(String newSrc)
		{
			this.m_StrSource = newSrc;
			this.Tokenize();
		}

		public void NewDelim(String newDel)
		{
			if (newDel.length() == 0) {
				this.m_StrDelimiter = " ";
			} else {
				this.m_StrDelimiter = newDel;
			}
			this.Tokenize();
		}

		public void NewDelim(char[] newDel)
		{
			String temp = new String(newDel);
			if (temp.length() == 0) {
				this.m_StrDelimiter = " ";
			} else {
				this.m_StrDelimiter = temp;
			}
			this.Tokenize();
		}

		public int CountTokens()
		{
			return this.m_Tokens.size();
		}

		public boolean  HasMoreTokens()
		{
			if (this.m_CurrIndex <= (this.m_Tokens.size() - 1)) {
				return true;
			} else {
				return false;
			}
		}

		public String NextToken()
		{
			String RetString = "";
			if (this.m_CurrIndex <= (this.m_Tokens.size() - 1)) {
				RetString =""+m_Tokens.get(m_CurrIndex);   // conArrayListToString(m_Tokens,m_CurrIndex);
				 this.m_CurrIndex++;                               
                                Math.min(this.m_CurrIndex, this.m_CurrIndex - 1);
				return RetString;
			} else {
				return null;
			}
		}

		public String Source =this.m_StrSource; 

		public String Delim = this.m_StrDelimiter;
		
                /*public String conArrayListToString(ArrayList g,int k)
                {
                String s1="";
                for (int i=0;i<g.size();i++){s1=s1+g.get(i);}
                
                
                return s1;
                }*/
                public int  incr(int a)
                 {                  
                    a++;
                    return a;
                }
	}


