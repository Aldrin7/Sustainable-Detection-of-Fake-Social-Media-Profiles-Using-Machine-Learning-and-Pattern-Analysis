/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.io;
import core.*;
import java.io.*;
/**
 *
 * @author ganesh
 */
public class ArffReader {

    	//stores attributes info

		protected   FastVector m_Attributes;
		//a StreamReader to read the target .arff file

		protected BufferedReader m_BufferReader;
		//check whether the reader should start to read instances data

		protected boolean  m_IsInDataArea = false;
		//stores the relation name

		protected   String m_RelationName = null;
		//stores the instances that have been read

		protected   FastVector m_Instances = null;
		// init a new ArffReader instance
		//
		// @param fullFilePath the target file path in string
		//
		public ArffReader(String fullFilePath) throws Exception
		{
                   // System.out.println("File Path="+fullFilePath);
			m_Attributes = new FastVector();
			try {
                               
                                FileInputStream fstream = new FileInputStream(fullFilePath);
                                // Get the object of DataInputStream
                                DataInputStream in = new DataInputStream(fstream);
                                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                                m_BufferReader=br;
				String bufLine = "";

				while ((bufLine = m_BufferReader.readLine())!=null) {
					//System.out.println(bufLine);
					bufLine = bufLine.trim();
					//clear the spaces before and end of the string
					//check whether the line starts with a comment marker, such as 
					// '%' and '#' or not, if no, then start parsing

					if ( (!bufLine.startsWith("#")) & (!bufLine.startsWith("%"))) {
						if ((m_RelationName == null)) {
							if ((bufLine.toLowerCase().contains("@relation"))) {
								//parses the relation name
								ReadRelationName(bufLine);
								//System.Console.WriteLine("RelationName:" & Me.m_RelationName)
							}


						} else {
							if ((bufLine.toLowerCase().contains("@attribute"))) {
								//parses attributes info
								ReadAttribute(bufLine);
							}

							if ((bufLine.toLowerCase().contains("@data"))) {
								//should start reading instances data from here
								m_IsInDataArea = true;
								//build an empty dataset
								m_Instances = new FastVector();
							}

							if ((m_IsInDataArea == true)) {
								//parses instance info
								ReadInstance(bufLine);
							}

						}

					}

				}
				m_BufferReader.close();
			} catch (Exception ex) {
				ex.printStackTrace();
                                System.out.println("ARFFREADER PROBLEM ");
			}
		}
                
                	
                public String get1RelationName() throws Exception
                               {
			
				if ((m_RelationName == null)) 
                                {
                                    	throw new Exception("Did not find the relation name.");
                                        
				}
				return m_RelationName;
                }

		public FastVector get1AttributesInfo() throws Exception {
			
				if ((m_RelationName == null)) {
					throw new Exception("Did not find the information for attributes.");
				}
				return m_Attributes;
			
		}

		public FastVector get1Instances() throws Exception {
			
				if ((m_Instances == null)) {
					throw new Exception("Dataset cannot be read, please check the arff file.");
				}
				return m_Instances;
			
		}
		
			

		// Parsing relation name from a string line
		// @param bufLine The string to parse
		private void ReadRelationName(String bufLine) throws Exception
		{
			try {
				utils.StringTokenizer rnameToken = new utils.StringTokenizer(bufLine, " ");
				String rname = "";
				//parsing relation name
				while ((rnameToken.HasMoreTokens())) {
					String flag = rnameToken.NextToken();
					if ((flag.toLowerCase().contains("@relation"))) {
						rname = rnameToken.NextToken();
						m_RelationName = rname;
					}
					break; // TODO: might not be correct. Was : Exit While
				}
			} catch (Exception ex) {
				throw new Exception(ex.toString());
			}
		}
		// Parsing an attribute from a string line
		// @param bufLine The string to parse
		private void ReadAttribute(String bufLine) throws Exception
		{
			try {
				String attName = "";
				String attTypeStr = "";
				//some arff contains 'tab' (chr(9)), this should be replaced
				//with 'space' before parsing
				bufLine = ReplaceTabWithSpace(bufLine);
                                
				utils.StringTokenizer attToken = new utils.StringTokenizer(bufLine, " ");
                                     
				while ((attToken.HasMoreTokens())) {
					String flag = attToken.NextToken();
					if ((flag.toLowerCase().contains("@attribute"))) {
						//While (attName = "")
						attName = attToken.NextToken();
						//End While
						while ((attToken.HasMoreTokens())) {
							attTypeStr = attTypeStr + attToken.NextToken();
                                                       
						}

						break; // TODO: might not be correct. Was : Exit While
					}
				}
				attTypeStr = attTypeStr.trim();
				//System.Console.WriteLine("attName: " & attName)
				//System.Console.WriteLine("attTypeStr: " & attTypeStr)
				core.Attribute att = null;
				if ((attTypeStr.toLowerCase().contains("{") & attTypeStr.contains("}"))) {
					//nominal attribute
					att = new core.Attribute(attName, ParseAttributeValues(attTypeStr), m_Attributes.Size());
                                            // System.out.println(att);
				} else {
					if ((attTypeStr.toLowerCase().contains("numeric") | attTypeStr.toLowerCase().contains("real"))) {
						//numeric attribute
						att = new core.Attribute(attName, m_Attributes.Size());
					}

				}
				//add a new attribute
                                //System.out.println(att);
				m_Attributes.AddElement(att);
			} catch (Exception ex) {
				throw new Exception(ex.toString());
			}

		}

		// Parsing an instance info from a string line
		// @param line The string to parse

		private void ReadInstance(String line) throws Exception
		{
			try {
				line = line.trim();
				if ((!line.startsWith("@"))) {
					utils.StringTokenizer instValuesToken = new utils.StringTokenizer(line, ",");
					int index = 0;

					Instance inst;// = new Instance();
					double[] instArray = new double[m_Attributes.Size()];
					//parsing an instance data
					while ((instValuesToken.HasMoreTokens())) {
						String val = instValuesToken.NextToken().trim();
                                                
						core.Attribute att = null;
						att = (core.Attribute)(m_Attributes.ElementAt(index));
                                                
						if ((att.IsNominal())) {
							int i = 0;
							int tarIndex = 0;

							for (i = 0; i <= (att.NumValues() - 1); i++) {
                                                            //System.out.println("att vAl= "+att.Value(i).trim());
                                                            //System.out.println("VAL= "+val);
								if ((att.Value(i).trim().equals(val))) {
									tarIndex = i;
                                                                      }
							}

							if ((val.contains("?"))) {
								instArray[index] = Double.NaN;
							} else {
								instArray[index] = Double.parseDouble(String.valueOf(tarIndex));
							}
							index = index + 1;
						}

						if ((att.IsNumeric())) {
							if ((val.contains("?"))) {
								instArray[index] = Double.NaN;
							} else {
								instArray[index] = Double.parseDouble(val);
							}

							index = index + 1;
						}
					}

					inst = new Instance(1, instArray);
                                       //System.out.println(inst);
					m_Instances.AddElement(inst);

				}
			} catch (Exception ex) {
				ex.printStackTrace();
                                System.out.print("ARFFREADER READ INSTANCE ");
			}
		}
		// Clears the 'tab' char in a string, then replaced with 'space' char
		private String ReplaceTabWithSpace(String str)
		{
			//str = str.Replace(", ", ",")
			return str.replace("\t", " ");
		}
		private FastVector ParseAttributeValues(String attTypeStr) throws Exception
		{
			FastVector attVals = new FastVector();
			try {
				utils.StringTokenizer valuesToken = new utils.StringTokenizer(attTypeStr, ",");
				while ((valuesToken.HasMoreTokens())) {
					String val = valuesToken.NextToken();
                                        
					val = val.trim();
                                        //System.out.println(val);
					if ((val.endsWith("}"))) {
						val = val.substring(0, val.length() - 1);
                                                 
					}
					if ((val.startsWith("{"))) {
						val = val.substring(1, val.length());
                                            
					}
                                        //System.out.println(val);
					attVals.AddElement(val);
				}

			} catch (Exception ex) {
				throw new Exception(ex.toString());
			}
			return attVals;
		}


       
                
                
}
