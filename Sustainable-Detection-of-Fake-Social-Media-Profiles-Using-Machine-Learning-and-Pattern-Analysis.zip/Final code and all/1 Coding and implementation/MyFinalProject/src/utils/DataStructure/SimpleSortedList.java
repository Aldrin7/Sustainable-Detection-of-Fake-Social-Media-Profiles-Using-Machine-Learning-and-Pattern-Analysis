/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.DataStructure;

import java.lang.reflect.Array;

/**
 *
 * @author vibha
 */
public class SimpleSortedList {
                private Object[] data;
		private double[] value;
		private int count;

		private int capacity;
		public SimpleSortedList()
		{
			init(20);
		}
		public SimpleSortedList(int capacity)
		{
			init(capacity - 1);
		}

		private void init(int size)
		{
			capacity = size;
			data = new Object[capacity];
			value = new double[capacity];
			value[0]=0.0;
			data[0] = null;
		}
		public Object GetElementAt(int index)
		{
			return data[index];
		}

		public void Add(Object element, double priority)
		{
			if ((count >= capacity)) {
				ExpandCapacity();
			}
			value[count] = priority;
			data[count] = element;
			count += 1;
		}
		public void BubbleDownSort()
		{
			int i = 0;
			int j = 0;
			for (i = count; i >= 1; i += -1) {
				for (j = count - i; j >= 1; j += -1) {
					if ((value[j - 1] < value[j])) {
						Object tempObj = data[j];
						double tempValue = value[j];

						data[j] = data[j - 1];
						value[j] = value[j - 1];

						data[j - 1] = tempObj;
						value[j - 1] = tempValue;
					}
				}
			}

		}

		public double GetValue(int index)
		{
			return value[index];
		}

		private void ExpandCapacity()
		{
			capacity = count * 2;
			Object[] elements = new Object[capacity + 1];
			double[] prioritys = new double[capacity + 1];
			Copy1(data, 0, elements, 0, data.length);
			Copy2(value, 0, prioritys, 0, data.length);
			data = elements;
			value = prioritys;

		}

		public void Clear()
		{
			int i = 0;
			for (i = 0; i <= count - 1; i++) {
				data[i] = null;
			}
			count = 0;
		}
		public int Length()
		{
			return count;
		}
                public void Copy1(Object a[],int indx1,Object b[],int indx2,int length1)
                { 
                    int j=indx2;
                    for(int i=indx1;i<length1;i++)
                    {
                        b[i]=a[j];
                        j++;
                    }
                }
                public void Copy2(double a[],int indx1,double  b[],int indx2,int length1)
                { 
                    int j=indx2;
                    for(int i=indx1;i<length1;i++)
                    {
                        b[i]=a[j];
                        j++;
                    }
                }
	}


