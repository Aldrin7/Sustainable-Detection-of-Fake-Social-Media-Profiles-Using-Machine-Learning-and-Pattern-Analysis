/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package classifiers.trees;
import core.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author vibha
 */
public class ID3 extends classifiers.Classifier {

     

        private core.Attribute m_Attribute;
        private ID3[] m_Successors;
        private double m_ClassValue;
        private double[] m_Distribution;
        private Instances m_Data;
        private int m_NumInstancesOfLeaf;
        private core.Attribute m_ClassAttribute;
        //
        //Returns a string describing classifier
        //@return a description suitable for
        //displaying in the explorer gui
        //
        @Override
        public String GlobalInfo()
        {

            return "Class for constructing an unpruned decision tree based on the ID3 " + "algorithm. Can only deal with nominal attributes. No missing values " + "allowed. Empty leaves may result in unclassified instances. For more " + "information see: " + System.getProperty("line.separator") + " R. Quinlan (1986). 'Induction of decision " + "trees'. Machine Learning. Vol.1, No.1, pp. 81-106";
        }
        //
        // Generates the classifier.
        //
        // @param instances set of instances serving as training data 
        // @exception Exception if the classifier has not been generated successfully
        //'
        @Override
        public void BuildClassifier(Instances data)
        {

            try
            {
                if ((!data.ClassAttribute().IsNominal()))
                {
                    throw new Exception("Id3: nominal class only, please.");
                }
                Enumeration enumAtt = data.EnumerateAttributes();
                while ((enumAtt.HasMoreElements()))
                {
                    core.Attribute att = (core.Attribute)enumAtt.NextElement();
                    if ((!att.IsNominal()))
                    {
                        //data = new Instances(data);
                        //data.DeleteWithMissingClass();
                        //m_Data = new Instances(data);
                        //if ((m_Data.NumInstances() <= 300))
                        //{
                        //    m_NumInstancesOfLeaf = Convert.ToInt32((m_Data.NumInstances() * 0.01));
                        //}
                        //else
                        //{
                        //    m_NumInstancesOfLeaf = 4;
                        //}
//                        Rain_Forest c = new Rain_Forest();
                       // c.ClassifyInstance(m_Data);
                        //build tree recursively
                        //MakeTree(data);
                       throw new Exception("Id3: nominal attributes only, please.");
                    }
                }
                Enumeration instEnum = data.EnumerateInstances();
                while ((instEnum.HasMoreElements()))
                {
                    Instance inst = (Instance)instEnum.NextElement();
                    if ((inst.HasMissingValue()))
                    {
                        throw new Exception("Id3: no missing values, please.");
                    }
                }

                data = new Instances(data);
                data.DeleteWithMissingClass();

                MakeTree(data);

            }
            catch (Exception ex)
            {
              ex.printStackTrace();
            }

        }
        //
        // Classifies a given instance.
        //
        // @param instance the instance to be classified
        // @return index of the predicted class
        //
        @Override
        public  double ClassifyInstance(Instance instance)
        {

            try
            {
                if ((instance.HasMissingValue()))
                {
                 //   throw new Exception("ID3: no missing values, please");
                }
                if ((m_Attribute == null))
                {
                    return m_ClassValue;
                }
                else
                {
                    return m_Successors[(int)(instance.Value(m_Attribute))].ClassifyInstance(instance);

                }

            }
            catch (Exception ex)
            {
                ex.printStackTrace();
                return 0;
            }
            
        }
        //
        // Calculates the class membership probabilities for the given test instance.
        //
        // @param instance the instance to be classified
        // @return predicted class probability distribution
        // @exception Exception if class is numeric
        //
        @Override
        public  double[] DistributionForInstance(Instance instance)
        {
            try
            {
                if ((instance.HasMissingValue()))
                {
                    throw new Exception("ID3: no missing values, please.");
                }
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }
            if ((m_Attribute == null))
            {
                return m_Distribution;
            }
            else
            {
                return m_Successors[(int)(instance.Value(m_Attribute))].DistributionForInstance(instance);
            }
        }
        //
        // Returns a description of the classifier.
        //
        // @return a description of the classifier as a string.
        //
        @Override
        public String toString()
        {
            if (((m_Distribution == null) & (m_Successors == null)))
            {
                return "Id3: No model built yet.";
            }
        try {
            return "ID3 Decision Tree" + System.getProperty("line.separator") +System.getProperty("line.separator") + toString(0);
        } catch (Exception ex) {
           ex.printStackTrace();
           return null;
        }
        }
        //
        // Returns a description of the classifier.
        //
        // @return a description of the classifier as a string.
        //
        private String toString(int level) throws Exception
        {
            StringBuilder text = new StringBuilder();
            if ((m_Attribute == null))
            {
                if (Boolean.parseBoolean(Instance.IsMissingValue(m_ClassValue).toString()))
                {
                    text.append(": null");
                }
                else
                {
                    text.append(": " + m_ClassAttribute.Value((int)(m_ClassValue)));
                }
            }
            else
            {
                int i = 0;
                int j = 0;
                for (j = 0; j <= m_Attribute.NumValues() - 1; j++)
                {
                    text.append(System.getProperty("line.separator"));
                    for (i = 0; i <= level - 1; i++)
                    {
                        text.append("|  ");
                    }
                    text.append(m_Attribute.Name() + " = " + m_Attribute.Value(j));
                    text.append(m_Successors[j].toString(level + 1));
                }
            }

            return text.toString();
        }
        //
        // Method for building an Id3 tree.
        // 
        // @param data the training data
        // @exception Exception if decision tree can't be built successfully
        // 
        private void MakeTree(Instances data) 
        {
            try
            {
                if ((data.NumInstances() == 0))
                {
                    m_Attribute = null;
                    m_ClassValue = Instance.MissingValue();
                    m_Distribution = new double[data.NumClasses()];
                    return;
                }

                double[] infoGains = null;
                infoGains = new double[data.NumAttributes()];
                Enumeration enumAtt = data.EnumerateAttributes();
                while ((enumAtt.HasMoreElements()))
                {
                    core.Attribute att = (core.Attribute)enumAtt.NextElement();
                    infoGains[att.Index()] = ComputeInfoGain(data, att);
                }
                m_Attribute = data.Attribute(utils.Utils.MaxIndex(infoGains));

                if ((utils.Utils.Eq(infoGains[(int)( m_Attribute.Index())], 0)))
                {
                    m_Attribute = null;
                    m_Distribution = new double[data.NumClasses()];
                    Enumeration instEnum = data.EnumerateInstances();

                    while ((instEnum.HasMoreElements()))
                    {
                        Instance inst = (Instance)instEnum.NextElement();
                        m_Distribution[(int)(inst.ClassValue())] = m_Distribution[(int)(inst.ClassValue())] + 1;

                    }
                    //utils.Utils.Normalize(ref m_Distribution);
                    //*******************Normalize it Here instead of using utils.Utils.Normalize(ref m_Distribution);
                    double sum = 0;
			int i = 0;
			for (i = 0; i <= m_Distribution.length - 1; i++) {
				sum += m_Distribution[i];
			}
                    if (Double.isNaN(sum)) {
				throw new Exception("Can't normalize array. Sum is NaN.");
			}
			if ((sum == 0)) {
				throw new Exception("Can't normalize array. Sum is zero.");
			}
			
			for (i = 0; i <= m_Distribution.length - 1; i++) {
				m_Distribution[i] /= sum;
			}
                    //*******************
                    
                    
                    m_ClassValue = utils.Utils.MaxIndex(m_Distribution);

                    m_ClassAttribute = data.ClassAttribute();

                }
                else
                {
                    Instances[] splitDatasets = null;
                    splitDatasets = SplitData(data, m_Attribute);

                    m_Successors = new ID3[m_Attribute.NumValues()];

                    int j = 0;

                    for (j = 0; j <= m_Attribute.NumValues()- 1; j++)
                    {
                        m_Successors[j] = new ID3();
                        m_Successors[j].MakeTree(splitDatasets[j]);

                    }

                }
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }
        //
        // Computes information gain for an attribute.
        // 
        // @param data the data for which info gain is to be computed
        // @param att the attribute
        // @return the information gain for the given attribute and data
        // 
        private double ComputeInfoGain(Instances data, core.Attribute att)
        {

            double infoGain = ComputeEntropy(data);

            try
            {
                Instances[] splitDatasets = null;
                splitDatasets = SplitData(data, att);
                int j = 0;
                for (j = 0; j <= att.NumValues() - 1; j++)
                {
                    if ((splitDatasets[j].NumInstances() > 0))
                    {
                        infoGain -= ((double)(splitDatasets[j].NumInstances()) / (double)(data.NumInstances())) * ComputeEntropy(splitDatasets[j]);
                    }

                }
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }

            return infoGain;
        }
        //
        // Computes the entropy of a dataset.
        // 
        // @param data the data for which entropy is to be computed
        // @return the entropy of the data's class distribution
        // 
        private double ComputeEntropy(Instances data)
        {
            double entropy = 0;

            try
            {
                double[] classCounts = new double[data.NumClasses()];
                Enumeration instEnum = data.EnumerateInstances();
                while ((instEnum.HasMoreElements()))
                {
                    Instance inst = (Instance)instEnum.NextElement();
                    classCounts[(int)(inst.ClassValue())] = classCounts[(int)(inst.ClassValue())] + 1;

                }

                int j = 0;

                for (j = 0; j <= data.NumClasses() - 1; j++)
                {

                    if ((classCounts[j] > 0))
                    {
                        entropy -= classCounts[j] * utils.Utils.Log2(classCounts[j]);

                    }
                }
                entropy /= (double)(data.NumInstances());
            }
            catch (Exception ex)
            {
            ex.printStackTrace();
            }

            return entropy + (utils.Utils.Log2(data.NumInstances()));
        }
        //
        // Splits a dataset according to the values of a nominal attribute.
        // 
        // @param data the data which is to be split
        // @param att the attribute to be used for splitting
        // @return the sets of instances produced by the split
        //
        private Instances[] SplitData(Instances data, core.Attribute att) throws Exception
        {

            Instances[] splitDatasets = null;
            splitDatasets = new Instances[att.NumValues()];
            int i = 0;
            int j = 0;
            for (j = 0; j <= att.NumValues() - 1; j++)
            {
                splitDatasets[j] = new Instances(data, data.NumInstances());
            }
            Enumeration instEnum = data.EnumerateInstances();
            while ((instEnum.HasMoreElements()))
            {
                Instance inst = (Instance)instEnum.NextElement();
                splitDatasets[(int)(inst.Value(att))].Add(inst);
            }

            for (i = 0; i <= splitDatasets.length - 1; i++)
            {
                splitDatasets[i].Compactify();
            }

            return splitDatasets;
        }

        // return a drawablw tree node
        // @param
        //
        //
        //////public classifiers.trees.B45.TreeVisualizer.Node TreeNodeGraph()
        //////{
        //////    if (((m_Distribution == null) & (m_Successors == null)))
        //////    {
        //////        return null;
        //////    }
        //////    return TreeNodeGraph(0);
        //////}
        // return a drawablw tree node
        // @param level 
        //
        //////public classifiers.trees.B45.TreeVisualizer.Node TreeNodeGraph(int level)
        //////{
        //////    vbWeka.classifiers.trees.B45.TreeVisualizer.Node treeGraph = new vbWeka.classifiers.trees.B45.TreeVisualizer.Node();
        //////    if ((m_Attribute == null))
        //////    {
        //////        if ((Instance.IsMissingValue(m_ClassValue)))
        //////        {
        //////            treeGraph.Children = null;
        //////            treeGraph.ClassValue = "Nothing";
        //////            treeGraph.Element = "Nothing";
        //////        }
        //////        else
        //////        {
        //////            treeGraph.Children = null;
        //////            treeGraph.ClassValue = m_ClassAttribute.Value(int.Parse(m_ClassValue));
        //////            treeGraph.Element = m_ClassAttribute.Value(int.Parse(m_ClassValue));
        //////        }
        //////    }
        //////    else
        //////    {
        //////        int j = 0;

        //////        treeGraph.ClassValue = m_ClassValue;
        //////        treeGraph.Element = m_Attribute.Name();
        //////        treeGraph.Children = new vbWeka.classifiers.trees.B45.TreeVisualizer.Node[m_Attribute.NumValues];
        //////        for (j = 0; j <= m_Attribute.NumValues - 1; j++)
        //////        {
        //////            treeGraph.Children(j) = m_Successors[j].TreeNodeGraph(level + 1);
        //////            treeGraph.Children(j).InLineValue = m_Attribute.Value(j);

        //////        }
        //////    }
        //////    return treeGraph;
        //////}

    
}
