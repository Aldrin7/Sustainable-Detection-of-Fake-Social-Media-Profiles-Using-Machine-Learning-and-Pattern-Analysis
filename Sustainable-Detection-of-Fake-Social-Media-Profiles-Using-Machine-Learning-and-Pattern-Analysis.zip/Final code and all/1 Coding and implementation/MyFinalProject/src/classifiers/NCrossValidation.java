/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package classifiers;
import  core.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
/**
 *
 * @author vibha
 */
public class NCrossValidation {
    
    private int m_NumFolds;
        private double mp;
		private Instances m_Dataset;
		private double m_SampleError = 0;
        private double TimeD=0;
        double predict = 0;
		private double[] CONFIDENCE_LEVEL_CONSTANTS = {2.58,2.33,1.96,1.64,1.28,1.0,0.67};
		public NCrossValidation(Instances data, int numFolds) throws Exception
		{
			m_NumFolds = numFolds;
			m_Dataset = new Instances(data);
		}
      
        public void getPre(Classifier classifier,Instance ins) throws Exception
        {
            m_Dataset.Add(ins);
            int i = 0;
            int j = 0;
            int numCrt = 0;
            int numIncrt = 0;
            double m_SampleError1 = 0;
            DateFormat dtfrmt=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date dtStart = new Date();
            for (i = 0; i <= m_NumFolds - 1; i++)
            {
                Classifier copyClassifier = classifier;
                Instances test = m_Dataset.TestCV(m_NumFolds, i);
                Instances train = m_Dataset.TrainCV(m_NumFolds, i);

                //copyClassifier.BuildClassifier(train);

                for (j = 0; j <= test.NumInstances() - 1; j++)
                {
                    double predict = 0;
                    double real = 0;
                    Instance inst = test.GetInstance(j);
                    predict = classifier.ClassifyInstance(ins);
                    mp = predict;
                    real = inst.ClassValue();
                    if ((predict == real))
                    {
                        numCrt = numCrt + 1;
                    }
                    else
                    {
                        numIncrt = numIncrt + 1;
                    }
                }
                int sum = (numCrt + numIncrt);
                m_SampleError1 = m_SampleError1 + (double)numCrt/(double)sum;
            }
            
            Date dtEnd = new Date();
            double d1=dtStart.getTime();
              double d2=dtEnd.getTime();
              
            TimeD =(double) (d2-d1)/1000;
            // get the average error rate
            m_SampleError = m_SampleError1 / m_NumFolds;
        }


		public void EvaluateModel(Classifier classifier) throws Exception
		{
			Random rand = new Random();
            m_Dataset.Randomize(rand);
			m_Dataset.Stratify(m_NumFolds);
            
			int i = 0;
			int j = 0;
			int numCrt = 0;
			int numIncrt = 0;
            double m_SampleError1=0;
            DateFormat dtfrmt=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date dtStart = new Date();
			for (i = 0; i <= m_NumFolds - 1; i++) {
				Classifier copyClassifier = classifier;
				Instances test = m_Dataset.TestCV(m_NumFolds, i);
				Instances train = m_Dataset.TrainCV(m_NumFolds, i, rand);

				copyClassifier.BuildClassifier(train);

				for (j = 0; j <= test.NumInstances() - 1; j++) {
					
					double real = 0;
					Instance inst = test.GetInstance(j);
					predict = classifier.ClassifyInstance(inst);
					real = inst.ClassValue();
					if ((predict == real)) {
						numCrt = numCrt + 1;
					} else {
						numIncrt = numIncrt + 1;
					}
				}
                int sum = (numCrt + numIncrt);
                 m_SampleError1 = m_SampleError1 + ((double)numCrt / (double)sum);
			}
            
            Date dtEnd = new Date();
            double dd1=dtStart.getTime();
            double dd2=dtEnd.getTime();
            TimeD = (dd2 - dd1)/1000;
            TimeD=TimeD/m_NumFolds;
			// get the average error rate
			m_SampleError = m_SampleError1 / m_NumFolds;
		}
		//return the sample error over n-folds cross validation
        public double Getprediction()
        {
            return predict;
        }
		public double GetSampleError()
		{
			return m_SampleError;
		}
        public double getDiff()
        {
            return TimeD;
        }
		//set the number of folds for cross validation
		public void SetNumOfFolds(int n)
		{
			m_NumFolds = n;
		}
		//get the number of folds for cross validation
		public int GetNumOfFolds()
		{
			return m_NumFolds;
		}
		//output the true error at Z level confidence interval
		//The true error is calculated by ERRORs(h) +/- Zn * SQRT(ERRORs(h)*(1-ERRORs(h))/n)
		//S - the dataset
		//h - hypotheses
		//n - number of instances of S
		//z - confidence level
		//ERRORs(h) - sample error 
		public String OutputConfidenceIntervalForTrueError(double z)
		{
			double i = 1.96*z * Math.sqrt((m_SampleError * (1 - m_SampleError)) / m_Dataset.NumInstances());
			String str = "" + m_SampleError + " +/- " + i;
			return str;
		}
		public String OutputConfidenceIntervalForTrueError()
		{
			double i = 1.96 * Math.sqrt((m_SampleError * (1 - m_SampleError)) / m_Dataset.NumInstances());
			String str = "Error Rate = " + m_SampleError + " +/- " + i;
			return str + System.getProperty("line.separator") + "Is good Approximation (" + IsGoodApproximation() + ")";
		}
		public int GetNumOfInstances()
		{
			return m_Dataset.NumInstances();
		}
		
		private boolean  IsGoodApproximation()
		{
			if (((this.GetNumOfInstances() * this.GetSampleError() * (1 - this.GetSampleError())) >= 5)) {
				return true;
			} else {
				return false;
			}
		}

}
