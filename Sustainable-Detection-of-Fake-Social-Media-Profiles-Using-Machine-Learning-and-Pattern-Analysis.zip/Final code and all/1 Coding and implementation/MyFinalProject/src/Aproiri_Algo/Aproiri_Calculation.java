/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Aproiri_Algo;


import java.io.*;
import java.util.*;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import myfinalproject.MyDataSet;

/**
 *
 * @author vibha
 */
public class Aproiri_Calculation
{
    Vector<String> candidates=new Vector<String>(); //the current candidates
    //String configFile="config.txt"; //configuration file
    String transaFile="transa.txt"; //transaction file
    String outputFile="apriori-output.txt";//output file
    int numItems; //number of items per transaction
    int numTransactions; //number of transactions
    double minSup; //minimum support for a frequent itemset
    ArrayList<String> oneVal; //array of value per column that will be treated as a '1'
    String itemSep = " "; //the separator value for items in the database
    ArrayList<ArrayList<String>> MyList;
    DefaultListModel dlm1=new DefaultListModel();
    public static double Acc=0;
    public static double Etime=0;
    public static double Mem=0;
       int sum=0;
       int Tctr=0;
       int Fctr=0;
    
    public Aproiri_Calculation(int numItem,int numTrans,int minsup,String outputF,String inputF,ArrayList<String> Attribute,ArrayList<ArrayList<String>> ad)
    {
       numItems=numItem ;
       numTransactions=numTrans ;
       minSup=minsup ;
       transaFile =inputF;
       outputFile =outputF;
       // MyList= new ArrayList<MyDataSet>(numTrans);
       MyList=ad;
       oneVal = Attribute;
       int sum=0;
       int Tctr=0;
       int Fctr=0;
    }
    
    /************************************************************************
     * Method Name  : aprioriProcess
     * Purpose      : Generate the apriori itemsets
     * Parameters   : None
     * Return       : None
     *************************************************************************/
    public DefaultListModel aprioriProcess()
    {
        Date d; //date object for timing purposes
        long start, end; //start and end time
        int itemsetNumber=0; //the current itemset being looked at
        
        //Show the default Config*******************
        dlm1.addElement("\nDefault Configuration: ");
        dlm1.addElement("\n\t MS ACESS DATABASE FILE...");
    
        dlm1.addElement("\n\tTransa File: " + transaFile);
        
                 dlm1.addElement("\nInput configuration: "+numItems+" items, "+numTransactions+" transactions, ");
             dlm1.addElement("\nminsup = "+minSup+"%");
             dlm1.addElement("\n");
             minSup/=100.0;
       
             
             //***************************
             
        dlm1.addElement("\n APROIRI algorithm has started.\n");

        //start timer
        d = new Date();
        start = d.getTime();

        //while not complete
        do
        {
            //increase the itemset that is being looked at
            itemsetNumber++;

            //generate the candidates
            generateCandidates(itemsetNumber);

            //determine and display frequent itemsets
            calculateFrequentItemsets(itemsetNumber);
            if(candidates.size()!=0)
            {
               dlm1.addElement("\nFrequent " + itemsetNumber + "-itemsets");
                dlm1.addElement("\n"+candidates);
            }
        //if there are <=1 frequent items, then its the end. This prevents reading through the database again. When there is only one frequent itemset.
        }while(candidates.size()>1);

        //end timer
        d = new Date();
        end = d.getTime();

        double currentMemory = ( (double)((double)(Runtime.getRuntime().totalMemory()/1024)/1024))- ((double)((double)(Runtime.getRuntime().freeMemory()/1024)/1024)); 
        dlm1.addElement("\n Total Memory Used : "+currentMemory +"  \t MB");
        Mem=currentMemory;
        //display the execution time
        dlm1.addElement("\nExecution time is: "+((double)(end-start)/1000) + " \t M.seconds.");
        Etime=((double)(end-start)/1000);
        sum=Tctr+Fctr;
        dlm1.addElement("\n Accracy  is: "+(double)(((double)Fctr/(double)sum)*100) + " \t %.");
        Acc=(double)(((double)Fctr/(double)sum)*100) ;
        return dlm1;
    }

    /************************************************************************
     * Method Name  : generateCandidates
     * Purpose      : Generate all possible candidates for the n-th itemsets
     *              : these candidates are stored in the candidates class vector
     * Parameters   : n - integer value representing the current itemsets to be created
     * Return       : None
     *************************************************************************/
    private void generateCandidates(int n)
    {
        Vector<String> tempCandidates = new Vector<String>(); //temporary candidate string vector
        String str1, str2; //strings that will be used for comparisons
        StringTokenizer st1, st2; //string tokenizers for the two itemsets being compared

        //if its the first set, candidates are just the numbers
        if(n==1)
        {
            for(int i=1; i<=numItems; i++)
            {
               tempCandidates.add(Integer.toString(i));
            }
            
            
                       
        }
        else if(n==2) //second itemset is just all combinations of itemset 1
        {
            //add each itemset from the previous frequent itemsets together
            for(int i=0; i<candidates.size(); i++)
            {
                st1 = new StringTokenizer(candidates.get(i));
                str1 = st1.nextToken();
                for(int j=i+1; j<candidates.size(); j++)
                {
                    st2 = new StringTokenizer(candidates.elementAt(j));
                    str2 = st2.nextToken();
                    tempCandidates.add(str1 + " " + str2);
                }
            }
        }
        else
        {
            //for each itemset
            for(int i=0; i<candidates.size(); i++)
            {
                //compare to the next itemset
                for(int j=i+1; j<candidates.size(); j++)
                {
                    //create the strigns
                    str1 = new String();
                    str2 = new String();
                    //create the tokenizers
                    st1 = new StringTokenizer(candidates.get(i));
                    st2 = new StringTokenizer(candidates.get(j));

                    //make a string of the first n-2 tokens of the strings
                    for(int s=0; s<n-2; s++)
                    {
                        str1 = str1 + " " + st1.nextToken();
                        str2 = str2 + " " + st2.nextToken();
                    }

                    //if they have the same n-2 tokens, add them together
                    if(str2.compareToIgnoreCase(str1)==0)
                        tempCandidates.add((str1 + " " + st1.nextToken() + " " + st2.nextToken()).trim());
                }
            }
        }
        //clear the old candidates
        candidates.clear();
        //set the new ones
      candidates = new Vector<String>(tempCandidates);
        tempCandidates.clear();
    }
    
    
    
    public boolean  MachMyDtstNew(ArrayList<String> d1,ArrayList<String> d2,int j)
    {
        if(d1.get(j).equalsIgnoreCase(d2.get(j)))
        {
            return true;
        }else
        {
            return false;
        }
    }
    public boolean  MachMyDtst(MyDataSet d1,MyDataSet d2,int j)
    {
        switch(j)
        {
            case 0:
                if(d1.age.equalsIgnoreCase(d2.age))  {return true;}
                  else{return  false;}
                
            case 1:
               if(d1.sex.equalsIgnoreCase(d2.sex))  {return true;}
                  else{return  false;}
               
            case 2:
               if(d1.occupation.equalsIgnoreCase(d2.occupation))  {return true;}
                  else{return  false;}
               
            case 3:
                if(d1.familyhistroy.equalsIgnoreCase(d2.familyhistroy))  {return true;}
                  else{return  false;}   
            case 4:
               if(d1.smoking.equalsIgnoreCase(d2.smoking))  {return true;}
                else{return  false;}
               
               case 5:
               if(d1.alchohal.equalsIgnoreCase(d2.alchohal))  {return true;}
                else{return  false;}
               
               case 6:
               if(d1.tobacco.equalsIgnoreCase(d2.tobacco))  {return true;}
                else{return  false;}
               
               case 7:
               if(d1.weight.equalsIgnoreCase(d2.weight))  {return true;}
                else{return  false;}
               
               case 8:
               if(d1.cholestrol.equalsIgnoreCase(d2.cholestrol))  {return true;}
                else{return  false;}
               
               case 9:
               if(d1.HBP.equalsIgnoreCase(d2.HBP))  {return true;}
                else{return  false;}
               
               case 10:
               if(d1.LBP.equalsIgnoreCase(d2.LBP))  {return true;}
                else{return  false;}
               
               case 11:
               if(d1.Diabetes.equalsIgnoreCase(d2.Diabetes))  {return true;}
                else{return  false;}
               
               case 12:
               if(d1.Stress.equalsIgnoreCase(d2.Stress))  {return true;}
                else{return  false;}
               
               case 13:
               if(d1.target.equalsIgnoreCase(d2.target))  {return true;}
                else{return  false;}
               
               
              default:return false;
        }
        
    }
    

    /************************************************************************
     * Method Name  : calculateFrequentItemsets
     * Purpose      : Determine which candidates are frequent in the n-th itemsets
     *              : from all possible candidates
     * Parameters   : n - iteger representing the current itemsets being evaluated
     * Return       : None
     *************************************************************************/
    
    
    private void calculateFrequentItemsets(int n)
    {
        Vector<String> frequentCandidates = new Vector<String>(); //the frequent candidates for the current itemset
        //FileInputStream file_in; //file input stream
        //BufferedReader data_in; //data input stream
        FileWriter fw;
        BufferedWriter file_out;

        StringTokenizer st, stFile; //tokenizer for candidate and transaction
        boolean match; //whether the transaction has all the items in an itemset
        boolean trans[] = new boolean[numItems]; //array to hold a transaction so that can be checked
        int count[] = new int[candidates.size()]; //the number of successful matches

        try
        {
                //output file
                fw= new FileWriter(outputFile, true);
                file_out = new BufferedWriter(fw);
                //load the transaction file
                //file_in = new FileInputStream(transaFile);
                //data_in = new BufferedReader(new InputStreamReader(file_in));

                //for each transaction
                int MyFlag=0;
                for(int i=0; i<numTransactions; i++)
                {
                    //System.out.println("Got here " + i + " times"); //useful to debug files that you are unsure of the number of line
                    //stFile = new StringTokenizer(data_in.readLine(), itemSep); //read a line from the file to the tokenizer
                    //put the contents of that line into the transaction array
                    for(int j=0; j<numItems; j++)
                    {
                        ArrayList<String> newTest=new ArrayList<String>(numItems);
                        int ij=0;
                        while(ij<numItems)
                        {
                         newTest.add(MyList.get(ij).get(i));   
                         ij++;
                        }
                         trans[j]=MachMyDtstNew(newTest,oneVal,j);//MachMyDtst(MyList.get(i),oneVal,j);//trans[j]=(stFile.nextToken().compareToIgnoreCase(oneVal[j])==0); //if it is not a 0, assign the value to true
                         if(trans[j]==true)
                         {
                             Tctr++;
                             MyFlag=1;
                         }else
                         {
                             Fctr++;
                         }
                    }
                  
                    if(MyFlag==1 && n==1)
                    {
                        String theFoundLine="";
                        for(int kk=0;kk<numItems;kk++){
                            theFoundLine=theFoundLine+"        "+MyList.get(kk).get(i);
                        }
                        //theFoundLine=MyList.get(i).age+"     "+MyList.get(i).sex+"        "+MyList.get(i).occupation+"       "+MyList.get(i).familyhistroy+"        "+MyList.get(i).smoking+"       "+MyList.get(i).alchohal+"       "+MyList.get(i).tobacco+"       "+MyList.get(i).weight+"       "+MyList.get(i).cholestrol+"       "+MyList.get(i).HBP+"       "+MyList.get(i).LBP+"       "+MyList.get(i).Diabetes+"       "+MyList.get(i).Stress+"       "+MyList.get(i).target+"       ";
                        dlm1.addElement("\n"+theFoundLine);
                        MyFlag=0;
                        
                    }else{MyFlag=0;}
                    
                    
                    //check each candidate
                    for(int c=0; c<candidates.size(); c++)
                    {
                        match = false; //reset match to false
                        //tokenize the candidate so that we know what items need to be present for a match
                        st = new StringTokenizer(candidates.get(c));
                        //check each item in the itemset to see if it is present in the transaction
                        while(st.hasMoreTokens())
                        {
                            match = (trans[Integer.valueOf(st.nextToken())-1]);
                            if(!match) //if it is not present in the transaction stop checking
                                break;
                        }
                        if(match) //if at this point it is a match, increase the count
                            count[c]++;
                    }

                }
                if(count.length >= numItems)
                {
                    for(int g=0;g <count.length;g++)
                    {
                        String Myl="\n The Attribute : "+ (g+1) +" was Found  : "+count[g]+"  Times";
                        dlm1.addElement(Myl); 
                        System.out.println("\n The Attribute : "+ (g+1) +" was Found  : "+count[g]+"  Times"); 
                    }
                }
                
                for(int i=0; i<candidates.size(); i++)
                {
                    //  System.out.println("Candidate: " + candidates.get(c) + " with count: " + count + " % is: " + (count/(double)numItems));
                    //if the count% is larger than the minSup%, add to the candidate to the frequent candidates
                
                    if((count[i]/(double)numTransactions)>=minSup)
                    {
                        frequentCandidates.add(candidates.get(i));
                        //put the frequent itemset into the output file
                        file_out.write(candidates.get(i) + "," + count[i]/(double)numTransactions + "\n");
                    }
                }
                file_out.write("-\n");
                file_out.close();
        }
        //if error at all in this process, catch it and print the error messate
        catch(IOException e)
        {
            System.out.println(e);
        }
        //clear old candidates
        candidates.clear();
        //new candidates are the old frequent candidates
        candidates = new Vector<String>(frequentCandidates);
        frequentCandidates.clear();
    }
}

